import boto3, json, os
import psycopg2
from psycopg2 import OperationalError

endpoint_url = f"https://secretsmanager.{os.environ['AWS_REGION']}.amazonaws.com"

def get_secret():
    secret_name = os.environ['SECRET_NAME']  #"rds!cluster-2a35db06-981f-4ea0-b480-09832b69ea7d"
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        endpoint_url=endpoint_url
    )
    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except Exception as e:
        raise e
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            secret = get_secret_value_response['SecretBinary']
    print("I got Secrets")
    return secret

def connect_to_rds(secret, reader):
    try:
        connection_data = json.loads(secret)
        if reader:
            conn = psycopg2.connect(
                dbname=os.environ['DB_NAME'],
                user=connection_data['username'],
                password=connection_data['password'],
                host=os.environ['DB_ENDPOINT_READER'],
                port=os.environ['DB_PORT']
            )
        else :
            conn = psycopg2.connect(
                dbname=os.environ['DB_NAME'],
                user=connection_data['username'],
                password=connection_data['password'],
                host=os.environ['DB_ENDPOINT_WRITER'],
                port=os.environ['DB_PORT']
            )
        return conn
    except OperationalError as e:
        print("Error:", e)

def print_table(conn):
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM names;")
        rows = cursor.fetchall()
        if rows:
            return rows
        else:
            print("The 'names' table is empty.")
        cursor.close()
    except Exception as e:
        print("Error:", e)

        
def main(event, context):
    secret = get_secret()
    if "Type" in event and event["Type"] == "PUT":
        conn = connect_to_rds(secret, False)
        if conn:
            print("Connected to RDS Aurora PostgreSQL successfully!")
            create_table(conn)
            write_name(conn, event["Data"])
            conn.close()
            return f"Name {event['Data']} Added"
    else:
        conn = connect_to_rds(secret, True)
        if conn:
            print("Connected to RDS Aurora PostgreSQL successfully!")
            data = print_table(conn)
            conn.close()
            return json.dumps(str(data))
    return ""


def create_table(conn):
    try:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS names (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100) NOT NULL
            );
        """)
        conn.commit()
        print("Table created successfully!")
        cursor.close()
    except Exception as e:
        print("Error:", e)

def write_name(conn, name):
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO names (name) VALUES (%s);", (name,))
        conn.commit()
        print("Name inserted successfully!")
        cursor.close()
    except Exception as e:
        print("Error:", e)

# if __name__ == "__main__":
#     main()
